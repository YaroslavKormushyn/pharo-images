# Pharo Icon Packs
A repository to keep icon packs for Pharo IDE.

## Eclipse icon pack
This is a derivative from Eclipse icon pack, who are distributed under [Eclipse Public Licence v1.0](http://www.eclipse.org/legal/epl-v10.html)

