# Pharo Icon Packs
A repository to keep icon packs for Pharo IDE.

## Eclipse icon pack
This is a derivative from FamFamFam "Silk" icon pack, who are distributed under [Creative Commons Attribution 2.5 License](http://creativecommons.org/licenses/by/2.5/)

